
<?php $__env->startSection('title','แสดงข้อมูล Coffee Bean'); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Region</th>
        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $bean; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($item->bean_id); ?></td>
                <td><?php echo e($item->name); ?></td>
                <td><?php echo e($item->region); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('bean.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\งาน\1_67\PHP Web\projectwork\resources\views/bean/index.blade.php ENDPATH**/ ?>